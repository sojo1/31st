<?php
/*=================================
WARNING!!! 
AGAR SCRIP BISA BERJALAN HARAP INSTAL 
PHP, IMAGEMAGICK, TESSERACT  DI TERMUX
DENGAN CARA MENGETIK'KAN
pkg install php 
pkg install imagemagick
pkg install tesseract
==================================*/

$UA = "xxxxxxxxx";

$COOKIE = "xxxxxxxxxx";

$URL = "xxxxxxxxxxxx";

/*≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠
DUKUNG TERUS CREATOR AGAR
SEMAKIN SEMANGAT UNTUK
MEMBUAT SCRIP² TERBARU
≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠≠*/
?>