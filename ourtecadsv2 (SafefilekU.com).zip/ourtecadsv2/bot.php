<?php
error_reporting(0);
system("clear");
if (file_exists("cookie"))
{
}
else
{
    echo "\nmasukan cookie: ";
    $cookie = trim(fgets(STDIN));
    file_put_contents("cookie", $cookie);
}
system("clear");
class Ourtecads
{
    public function pars($awal, $akhir, $inti, $res)
    {
        $befor = explode($awal, $res);
        $after = explode($akhir, $befor[$inti]);

        return $after[0];
    }
    public function curl($url, $post = 0)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        if ($post)
        {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        }
        $headers = ["Host: ourtecads.com", "user-agent: Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10) AppleWebKit/537.36 (KHTML, like Gecko) Version/8.0 Safari/537.36", 'cookie: ' . file_get_contents('cookie') ];
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        return curl_exec($ch);
    }
    public function dashboard()
    {
        return $this->curl("https://ourtecads.com/v2/dashboard");
    }
    public function banner($balance)
    {
        $red = "\033[0;31m";
        $green2 = "\033[1;32m";
        $yellow = "\033[0;33m";
        $putih2 = "\033[1;37m";
        $blue = "\033[0;34m";
        $green = "\033[0;32m";
        $putih = "\033[0;37m";

        echo $red . "\n
███╗   ███╗██████╗    ███╗   ███╗██╗  ██╗     ██╗ ██████╗ ██████╗
████╗ ████║██╔══██╗   ████╗ ████║██║  ██║     ██║██╔═══██╗██╔══██╗
██╔████╔██║██████╔╝   ██╔████╔██║███████║     ██║██║   ██║██████
██║╚██╔╝██║██╔══██╗   ██║╚██╔╝██║╚════██║██   ██║██║   ██║██╔══██╗
██║ ╚═╝ ██║██║  ██║██╗██║ ╚═╝ ██║     ██║╚█████╔╝╚██████╔╝██║  ██║
╚═╝     ╚═╝╚═╝  ╚═╝╚═╝╚═╝     ╚═╝     ╚═╝ ╚════╝  ╚═════╝ ╚═╝  ╚═";
        echo $putih . "\nourtecads.com v2.0 Bypass antibot";
        echo $green2 . "\n≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈";
        echo $yellow . "\n>CREATOR  : " . $putih2 . "MR.M4JOR.EXE";
        echo $yellow . "\n>WHATSAPP : " . $putih2 . "0813 2775 3909";
        echo $yellow . "\n>YOUTUBE  : " . $putih2 . "MR.M4JOR. EXE";
        echo $green2 . "\n≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈";
        echo $blue . "\n>>>>>>>>>>>>>>>>>>>>>>>>>" . $putih . " DATA AKUN " . $blue . "<<<<<<<<<<<<<<<<<<<<<<<<<<<";
        echo $green2 . "\n≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈\n";
        echo $green . "\n•balance   : " . $putih . $balance . " Coins\n";
        echo $green2 . "\n≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈≈";
        echo "\n";
        return '';
    }
    public function timer($tmr)
    {
        $timr = time() + $tmr;
        while (true):
            echo "\r                       \r";
            $res = $timr - time();
            if ($res < 1)
            {
                break;
            }
            echo "\033[0;33mtunggu \033[1;37m" . date('H:i:s', $res);
            //	    $this->dashboard();
            sleep(1);
        endwhile;
    }

    public function verify($v1, $v2, $v3, $csrf, $token)
    {
        return $this->curl("https://ourtecads.com/v2/dashboard/verify", "antibotlinks=+" . $v1 . "+" . $v2 . "+" . $v3 . "&csrf_token_name=" . $csrf . "&token=" . $token);
    }
    public function csrf($res)
    {
        return $this->pars('name="csrf_token_name" id="token" value="', '">', 1, $res);
    }
    public function stay()
    {
        $menit = $this->pars('<b id="minute">', '</b>', 1, $this->dashboard());
        $detik = $this->pars('<b id="second">', '</b></h4>', 1, $this->dashboard());
    }
    public function token($res)
    {
        return $this->pars('name="token" value="', '">', 1, $res);
    }
    public function balance()
    {
        return $this->pars('<p class="acc-amount text-secondary pr-1 pt-2"><i class="fas fa-coins"></i> ', '</p>', 1, $this->dashboard());
    }
    public function claimed()
    {
        $this->banner($this->balance());
        while (true)
        {
            $dash = $this->dashboard();

            $claim = $this->verify($v1, $v2, $v3, $this->csrf() , $this->token());
            $message = $this->pars("text: '", "',", 1, $claim);
            $type = $this->pars("type: '", "',", 1, $claim);
            if ($type == "success")
            {
                echo "\n\033[1;37m" . $message . "\033[1;32m Total Balance: \033[1;37m" . $this->balance() . "\n";

            }
            else
            {
                echo "\n\033[1;34mGagal Claim, \033[1;31mPERIKSA COOKIE";
            }
        }
    }
}
$new = new Ourtecads();
echo $new->banner($new->balance());

while (true)
{
    $dash = $new->dashboard();
    $a = $new->pars('rel=\"', '\">', 1, $dash);
    $b = $new->pars('rel=\"', '\">', 2, $dash);
    $c = $new->pars('rel=\"', '\">', 3, $dash);
    $token = $new->token($dash);
    $csrf = $new->csrf($dash);

    $claim = $new->verify($a, $b, $c, $csrf, $token);
    $message = $new->pars("text: '", "',", 1, $claim);
    if ($message <= null)
    {
        echo "proses 1";
        usleep(300000);
        echo "\r                      \r";
    }
    else
    {
        echo "\n" . $message . " Total Balance: " . $new->balance() . "\n";
        echo $new->timer(300);
    }
    $claim = $new->verify($a, $c, $b, $csrf, $token);
    $message = $new->pars("text: '", "',", 1, $claim);
    if ($message <= null)
    {
        echo "proses 2";
        usleep(300000);
        echo "\r                      \r";
    }
    else
    {
        echo "\n" . $message . " Total Balance: " . $new->balance() . "\n";
        echo $new->timer(300);
    }
    $claim = $new->verify($b, $a, $c, $csrf, $token);
    $message = $new->pars("text: '", "',", 1, $claim);
    if ($message <= null)
    {
        echo "proses 3";
        usleep(300000);
        echo "\r                      \r";
    }
    else
    {
        echo "\n" . $message . " Total Balance: " . $new->balance() . "\n";
        echo $new->timer(300);
    }
    $claim = $new->verify($b, $c, $a, $csrf, $token);
    $message = $new->pars("text: '", "',", 1, $claim);
    if ($message <= null)
    {
        echo "proses 4";
        usleep(300000);
        echo "\r                      \r";
    }
    else
    {
        echo "\n" . $message . " Total Balance: " . $new->balance() . "\n";
        echo $new->timer(300);
    }
    $claim = $new->verify($c, $a, $b, $csrf, $token);
    $message = $new->pars("text: '", "',", 1, $claim);
    if ($message <= null)
    {
        echo "proses 5";
        usleep(300000);
        echo "\r                      \r";
    }
    else
    {
        echo "\n" . $message . " Total Balance: " . $new->balance() . "\n";
        echo $new->timer(300);
    }
    $claim = $new->verify($c, $b, $a, $csrf, $token);
    $message = $new->pars("text: '", "',", 1, $claim);
    if ($message <= null)
    {
        echo "proses 6";
        usleep(300000);
        echo "\r                      \r";
    }
    else
    {
        echo "\n" . $message . " Total Balance: " . $new->balance() . "\n";
        echo $new->timer(300);
    }
}

