<?php

$bnr="\033[1;37m
╔═════════════════════════════════╗
║\033[3m \033[4m\033[1;32mcreator \033[1;33m: \033[1;36m@cupiiz\033[0m		  \033[1;37m║\033[1;37m
║\033[3m \033[4m\033[1;32mgroup   \033[1;33m: \033[1;34m@kuli_online_group\033[0m	  \033[1;37m║\033[1;37m
║\033[3m \033[4m\033[1;32mchanel  \033[1;33m: \033[1;35m@kuli_online_channel\033[0m  \033[1;37m║\033[1;37m
╚═════════════════════════════════╝
\033[1;37mJika ada info baru kabarin cupiiz

";
$bot="JCX-@JzYW5kaSI6ImhNGTdHBzO+%wvXC9wYXNNGTZWJpbi5jb21cL3Jhd1wvVZ&JTUG+%NGTMGgiLCJ1cGRhdGVfc2FuZGkiOiJodHRwczpcL1wvcG9uc2VsaGF-@aWFuLmNvbVwvUkJGV1JNGTIZ&NGTFV8";

$yt="off";
$link="https://t.me/ngopi_aja";