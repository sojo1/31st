<?php
date_default_timezone_set("UTC");
include "cfg.php";
error_reporting(0);
// warna
$biru="\033[1;34m";
$kuning="\033[1;33m";
$merah="\033[1;31m";
$putih="\033[1;37m";
$hijau="\033[1;32m";
$cyan="\033[1;36m";
$ungu="\033[1;35m";
$dark="\033[1;30m";
$abu = "\033[0;90m";
$abu1 = "\033[1;90m";
$merah1 = "\033[1;91m";
$end = "\033[0m";
$blockabu = "\033[100m";
$blockmerah = "\033[101m";
$blockstabilo = "\033[102m";
$blockkuning = "\033[103m";
$blockbiru = "\033[104m";
$blockpink = "\033[105m";
$blockcyan = "\033[106m";
$blockputih = "\033[107m";
$panah = $cyan."⟫ ";
$green = "\e[1;32m";
$blockglow = "\033[102m";
$blue = "\e[1;34m";
$blockblue = "\033[104m";
$red = "\e[1;31m";
$blockred = "\033[101m";
$blockpink = "\033[105m";
$white = "\33[37;1m";
$blockwhite = "\033[107m";
$yellow = "\e[1;33m";
$blockyellow = "\033[103m";
$cyan = "\e[1;36m";
$blockcyan = "\033[106m";
$purple = "\e[1;35m";
$gray = "\e[1;30m";
$blockgray = "\033[100m";
$end = "\033[0m";

function strip(){
$green = "\e[1;32m";
$blue = "\e[1;34m";
$red = "\e[1;31m";
$white = "\33[37;1m";
$yellow = "\e[1;33m";
$cyan = "\e[1;36m";
$purple = "\e[1;35m";
$gray = "\e[1;30m";

echo$red."  ◼".$green."◼◼".$blue."◼◼".$white."◼◼".$yellow."◼◼".$cyan."◼◼".$purple."◼◼".$gray."◼◼".$red."◼◼".$green."◼◼".$blue."◼◼".$white."◼◼".$yellow."◼◼".$cyan."◼◼".$purple."◼◼".$gray."◼◼".$red."◼◼".$green."◼◼".$blue."◼◼".$white."◼◼".$yellow."◼◼".$cyan."◼◼".$purple."◼◼".$gray."◼◼".$green."◼◼".$red."◼\n";
}

function strip2(){
$green = "\e[1;32m";
$blue = "\e[1;34m";
$red = "\e[1;31m";
$white = "\33[37;1m";
$yellow = "\e[1;33m";
$cyan = "\e[1;36m";
$purple = "\e[1;35m";
$gray = "\e[1;30m";
$blockglow = "\033[102m";
$end = "\033[0m";
$strip2 = str_repeat($red."◼",56);
echo $strip2."\n";

}

function sruput(){
include('cfg.php');

$green = "\e[1;32m";
$blockglow = "\033[102m";
$blue = "\e[1;34m";
$blockblue = "\033[104m";
$red = "\e[1;31m";
$blockred = "\033[101m";
$blockpink = "\033[105m";
$white = "\33[37;1m";
$blockwhite = "\033[107m";
$yellow = "\e[1;33m";
$blockyellow = "\033[103m";
$cyan = "\e[1;36m";
$blockcyan = "\033[106m";
$purple = "\e[1;35m";
$gray = "\e[1;30m";
$blockgray = "\033[100m";
$end = "\033[0m";
$orange = "\033[38;5;202m";

echo$yellow."YouTube     : ".$red."GRATIS OKE \n";
echo$yellow."Telegram    : ".$green."@gratisokee\n";
echo$yellow."Script by   : ".$white."YzZz Tv\n";
}

function Get($url, $ua){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_ENCODING, "");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_TIMEOUT, 60);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
$result = curl_exec($ch);
curl_close($ch);
return $result; 
sleep(1);
}

function Post($link, $ua, $data){
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $link);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, $ua);
curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
curl_setopt($ch, CURLOPT_COOKIEJAR, "./cookie/cookie.txt");
curl_setopt($ch, CURLOPT_COOKIEFILE, "./cookie/cookie.txt");
$result = curl_exec($ch);
curl_close($ch);
return $result; 
}



function curl(
$url,$httpheader=0,$post=0,$request=0,$proxy=0){ 
// url, httpheaders, postdata, request, proxy
 $ch = curl_init();
 curl_setopt($ch, CURLOPT_URL, $url);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
 curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
 curl_setopt($ch, CURLOPT_COOKIEJAR, "cookie.txt");
 curl_setopt($ch, CURLOPT_COOKIEFILE, "cookie.txt");
 curl_setopt($ch, CURLOPT_TIMEOUT, 60);
 curl_setopt($ch, CURLOPT_HEADER, true);
  if($httpheader){
   curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
   }
  if($post){
   curl_setopt($ch, CURLOPT_POST, true);
   curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
   }
  if($request){
   curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $request);
   }
  if($proxy){
   curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, true);
   curl_setopt($ch, CURLOPT_PROXY, $proxy);
   curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
   }
 $response = curl_exec($ch);
 $httpcode = curl_getinfo($ch);
  if(!$httpcode) return "Curl Error : ".curl_error($ch); else{
 $header = substr($response, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
 $body = substr($response, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
 curl_close($ch);
 return array($header, $body);}
}

function c(){
$cooki = file_get_contents("cookie.txt");
$one = explode("XSRF-TOKEN	",$cooki);
$e = "
";
$two = explode($e,$one[1]);
$ca = "$two[0]";
$one = explode("laravel_session	",$cooki);
$two = explode($e,$one[1]);
$cb = "$two[0]";
$cookie = "XSRF-TOKEN=".$ca.";laravel_session=".$cb;
}

function head(){
include 'useragent.php';
$rand = rand(0,53);
  $ua[]="Host: litecoin.host";
  $ua[]="upgrade-insecure-requests: 1";
  $ua[]="user-agent: ".$rand_useragent[$rand];
}
/*
function wall(){
include "cfg.php";
$stop = "stop";
$wallet = array(
"$doge","$dash","$dgb","$trx","$sol","$stop"
);
return $wallet;
}

function web(){
include "cfg.php";
$website = array(
"$web_doge","$web_dash","$web_dgb","$web_trx","$web_sol","$stop"
);
return $website;
}
*/

//KALO SEMUA BISA WD TANPA DEPO, PAKAI FUNGSI INI

function wall(){
include "cfg.php";
$stop = "stop";
$wallet = array(
"$btc","$eth","$bnb","$fey","$bch","$usdt","$zec","$doge","$dash","$dgb","$trx","$sol","$stop"
);
return $wallet;
}

function web(){
include "cfg.php";
$website = array(
"$web_btc","$web_eth","$web_bnb","$web_fey","$web_bch","$web_usdt","$web_zec","$web_doge","$web_dash","$web_dgb","$web_trx","$web_sol","$stop"
);
return $website;
}


$walls=wall();
$wall=current($walls);
$webs=web();
$web=current($webs);

function wp(){
include "cfg.php";
global $web;
$url=$web;
return curl($url,head());
}

function login(){
include "cfg.php";
global $web,$token_log,$wall;
$url=$web."check";
$data=http_build_query(["_token"=>$token_log,"wallet"=>$wall]);
return curl($url,head(),$data);
}

function dashboard(){
include "cfg.php";
global $web;
$url=$web."account/";
return curl($url,head());
}

function wdp(){
include "cfg.php";
global $web;
$url=$web."account/withdraw";
return curl($url,head());
}

function wd(){
include "cfg.php";
global $web,$token,$track,$bal;
$url=$web."account/withdraw-post-faucetpay";
$data=http_build_query(["_token"=>$token, "track"=>$track, "amount"=>$bal]);
return curl($url,head(),$data);
}

system("clear");
strip2();
sruput();
strip2();

while(true):
$i=1;
while ($i){
if($web==$web_btc){
$batas = "        | ";
$c = "BTC";
$min_wd = "0.00000010";
}
if($web==$web_eth){
$batas = "        | ";
$c = "ETH";
$min_wd = "0.00000100";
}
if($web==$web_bch){
$batas = "        | ";
$c = "BCH";
$min_wd = "0.00000999";
}
if($web==$web_doge){
$batas = "       | ";
$c = "DOGE";
$min_wd = "0.02000000";
}
if($web==$web_dash){
$batas = "       | ";
$c = "DASH";
$min_wd = "0.00003000";
}
if($web==$web_dgb){
$batas = "       | ";
$c = "DGB";
$min_wd = "0.09999999";
}
if($web==$web_trx){
$batas = "       | ";
$c = "TRX";
$min_wd = "0.05000000";
}
if($web==$web_usdt){
$batas = "       | ";
$c = "USDT";
$min_wd = "0.00400000";
}
if($web==$web_fey){
$batas = "        | ";
$c = "FEY";
$min_wd = "0.50000000";
}
if($web==$web_bnb){
$batas = "        | ";
$c = "BNB";
$min_wd = "0.00000800";
}
if($web==$web_zec){
$batas = "        | ";
$c = "ZEC";
$min_wd = "0.00002000";
}
if($web==$web_sol){
$batas = "       | ";
$c = "SOL";
$min_wd = "0.00002000";
}

$wp=wp()[1];
$token_log = explode('name="_token" value="',$wp)[1];
$token_log = explode('"',$token_log)[0];
$login=login()[1];
$dashboard=dashboard()[1];
sleep(1);
$wd=wdp()[1];
$bal = explode('selected>',$wd)[1];
$bal = explode(' '.$c,$bal)[0];
$token = explode('name="_token" value="',$wd)[1];
$token = explode('"',$token)[0];
$track = explode('<option style="background: black;" value="',$wd)[2];
$track = explode('"',$track)[0];
echo $merah."[".$putih.$i.$merah."] ".$cyan.$c.$kuning.$batas.$blockmerah.$putih.$bal." ".$c.$end."\n";
if ($bal > $min_wd){
$wd=wd()[1];
$fail = explode('danger">',$wd)[1];
$fail = explode('</div>',$fail)[0];
if($fail<=null){
echo $hijau."Success Withdraw !\n";
}else{
echo $merah.$fail."\n";
}}
$wall = next($walls);
$web = next($webs);
system("rm cookie.txt");
if ($wall == "stop"){
strip2();
for($x=600;$x>0;$x--){echo "\r \r";
echo$gray." Wait..!! Nanti juga Whitdrow cuy ".$red."[".$yellow.$x.$red."] ☕🚬";
echo "\r \r";
sleep(1);}
echo "\r                                          \r";
$wall = reset($walls);
$web = reset($webs);
$i = 0;
}
$i=$i+1;
}
endwhile;