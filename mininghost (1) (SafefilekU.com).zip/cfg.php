<?php
//INPUT WALLET ADDRES DARI FAUCETPAY

$btc = "1FdSWBhWoMgdZnyHN3ZWH6Q7Re2JXeZxc7";
$eth = "0xb27272593effa7ebef5c1f160effbb9d76b4105f";
$bnb = "0x2b42Ac91ae7Efc153548deCc7F48C35D60a7638E";
$fey = "3Lgoce9d18Sr9tH6pSt2XyXdS1jZnxJz1F";
$bch = "bitcoincash:qrcga509dmvkdj7pm5agyk3y8585pz6hlqv5gk3lfr";
$usdt = "TBi1yHU6n1jYQH98wJELxE2C5ughURvoGw";
$zec = "t1NHaA5T5HqX81B6dvdQVxnvmticuKWGkim";
$doge = "DPLHnRoegKKNXeetQ5Qo8bzzJH6QUaGckh";
$dash = "XiZJmTjTUcYJLey1Q95hDcMRNwoPbD2aJ2";
$dgb = "DRpf6kxyNCivRtJyqb3j1hxJHyEFLkYpzP";
$trx = "TBi1yHU6n1jYQH98wJELxE2C5ughURvoGw";
$sol = "7w1keZPmSHER5HY9p4it2L2vSk5D4Twpy6zBkyQxDUds";
$stop = "stop";

//JANGAN DI APA APAIN
$web_btc = "https://litecoin.host/0/btc/";
$web_eth = "https://litecoin.host/0/eth/";
$web_bch = "https://litecoin.host/0/bch/";
$web_doge = "https://litecoin.host/0/doge/";
$web_dash = "https://litecoin.host/0/dash/";
$web_dgb = "https://litecoin.host/0/dgb/";
$web_trx = "https://litecoin.host/0/trx/";
$web_usdt = "https://litecoin.host/0/usdt/";
$web_fey = "https://litecoin.host/0/fey/";
$web_bnb = "https://litecoin.host/0/bnb/";
$web_zec = "https://litecoin.host/0/zec/";
$web_sol = "https://litecoin.host/0/sol/";
$stop = "stop";
