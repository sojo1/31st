<?php
//Isi Data sesuai contoh di bawah
$user ='Mozilla/5.0 (Linux; Android 9; Redmi Note 5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/86.0.4240.114 Mobile Safari/537.36';

$cookie ='bitmedia_fid=eyJmaWQiOiI5YmQ4MDlhNGMxY2UxZjQ4YzNjOWJkMzdkYzViYWQwNSIsImZpZG5vdWEiOiIyMTc1MmVjMDg5NzA1M2NmOTc3ZTE2MmRiMjQzYjViOCJ9;ci_session=41d3ebb3262b9bc7cf1d66c9920396eddb3ecdf3;csrf_cookie_name=9b697ec1c1854ba3f6ba87cc4dfb7647';
