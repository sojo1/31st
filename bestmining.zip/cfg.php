<?php

//cookie
$duid="xxx";

//datalogin
$in="xxx";
