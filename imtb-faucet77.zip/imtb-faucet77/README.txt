/** CARA MEMGGUNAKAN **/

Ketik perintah ini

$~ pkg update -y && pkg upgrade -y 
$~ pkg install php -y
$~ termux-setup-storage
$~ cd /sdcard/lokasifolderFileAnda!

Lalu start bot nya

ketik perintah

$~ php bot.php 

Untuk mengambil cookie bisa menggunakan Apps => Smart-Cookies, Kiwie Browser , Http Cannary, DLL 

Copy semua data cookie nya lalu pastekan data cfg.php di tengah tanda dua kutip => "cookieanda" <=

