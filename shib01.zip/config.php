<?php



$url = 'https://shiba100s.ga/claim.php?coin=SHIB';

$user = 'xxxxxxxx';

$cookie = 'PHPSESSID=6f27d7c683ba24fc6e199265;__dtsu=6D001634596844B558FD982CF269;SHIBToken=dNkRUV93Ajn0BnaNK7M5wi16aGJVS';












