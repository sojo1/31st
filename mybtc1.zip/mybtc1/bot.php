<?php
$res="\033[0m";
$abu2="\033[1;30m";
$putih="\033[0;37m";
$putih2="\033[1;37m";
$red="\033[0;31m";
$red2="\033[1;31m";
$green="\033[0;32m";
$green2="\033[1;32m";
$yellow="\033[0;33m";
$yellow2="\033[1;33m";
$blue="\033[0;34m";
$blue2="\033[1;34m";
$purple="\033[0;35m";
$purple2="\033[1;35m";

$reset="\033[0m";
$Black="\033[0;30m";
$Red= "\033[0;31m";
$Green="\033[0;32m";
$Yellow="\033[0;33m";
$Blue="\033[0;34m";
$Purple="\033[0;35m";
$Cyan="\033[0;36m";
$White="\033[0;37m";
$IYellow="\033[0;93m";
$IRed="\033[0;91m";
$BIRed="\033[1;91m";
$On_Cyan="\033[46m";
$BIWhite="\033[1;97m";
$BIBlue="\033[1;94m";
$BICyan="\033[1;96m";
$BIBlack="\033[1;90m";
$BBlack="\033[1;30m";
$IBlack="\033[0;90m";
$On_White="\033[47m";
$BIBlue="\033[1;94m";
$On_IRed="\033[0;101m";
$On_Red="\033[41m";
$On_Blue="\033[44m";
$On_Green="\033[42m";
$IGreen="\033[0;92m";

//red to yellow shade ↓
$r3="\033[01;38;5;196m";
$r2="\033[01;38;5;202m";
$r1="\033[01;38;5;208m";
$ry="\033[01;38;5;214m";
$y1="\033[01;38;5;220m";
$y2="\033[01;38;5;226m";
$y3="\033[01;38;5;228m";
system("clear");
error_reporting(0);
class mybtcads{

 public function msg($str){
  echo $str;
 }
 public function jeda(){
  return usleep(500000);
 }
 public function rm(){
  return "\r                         \r";
 }
  public function pars($awal,$akhir,$inti,$res){
   $a=explode($awal,$res);
   $b=explode($akhir,$a[$inti]);
   return $b[0];
  }
   public function curl($url, $post=0){
	include"cfg.php";
          $ch = curl_init();
          curl_setopt($ch, CURLOPT_URL, $url);
          curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
          curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
          curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
          curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
          curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
          curl_setopt($ch, CURLOPT_TIMEOUT, 60);
          if($post){
          curl_setopt($ch, CURLOPT_POST, true);
          curl_setopt($ch, CURLOPT_POSTFIELDS, $post);}
       	  $headers=array();
	  $headers[]="Host: mybtcads.com";
	  $headers[]="accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng;q=0.8,application/signed-exchange;v=b3;q=0.9";
	  $headers[]="User-Agent: ".$user_agent;
	  $headers[]="cookie: ".$cookie;
	  $headers[]="accept-language: en-US,en;q=0.9";
      	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
      return curl_exec($ch);
   }
   public function dash(){
    return $this->curl("https://mybtcads.com/dashboard.php");
   }
public function verify(){
 return $this->curl("https://mybtcads.com/inc/faucet.php");
}
public function surfad(){
  return $this->curl("https://mybtcads.com/surfads.php");
}
public function verify1($id){
  return $this->curl("https://mybtcads.com/inc/sf01credit.php","adid=".$id);
}
public function windowads(){
  return $this->curl("https://mybtcads.com/winads.php");
}
public function verify2($id1){
  return $this->curl("https://mybtcads.com/inc/ad01credit.php","adid=".$id1);
}
public function flashads(){
  return $this->curl('https://mybtcads.com/flashads.php');
}
public function verify3($id2){
  return $this->curl("https://mybtcads.com/inc/flash01credit.php","adid=".$id2);
}

 public function timer($tmr){
    $timr=time()+$tmr;
    while(true):
    echo "\r                       \r";
    $res = $timr-time();
    if($res < 1){
    break;
    }
    echo "\033[01;38;5;214mPlease Wait \033[01;38;5;202m[". date('i:s',$res)."]";
    sleep(1);
    endwhile;
   }}
 $new=new mybtcads();
include"cfg.php";
$title=$new->pars('<title>Dashboard | ','</title>',1,$new->dash());
$nama=$new->pars('mb-1">Welcome ','!</h3>',1,$new->dash());
$bal1 = "
                                        ";
$balance=$new->pars('<h2 class="text-dark mb-1 font-weight-medium">'.$bal1,'                                        </h2>',2,$new->dash());
echo "SCRIPT   = $title\n";
echo "Username = $nama\n";
echo "Balance  = $balance satoshi{$putih}\n";
echo "================================================\n";
echo "[1] Auto Faucet\n";
echo "[2] Surf Ads\n";
echo "[3] Window Ads\n";
echo "[4] Flash Ads\n";
$pilih = readline("Your answer : ");
echo "================================================\n";
sleep(2);

switch($pilih){
case 1;
echo $new->msg("Auto Faucet Started").$new->jeda().$new->rm();
while(true){
$go=$new->dash();
$claim=$new->verify();
$balance1=$new->pars('<h2 class="text-dark mb-1 font-weight-medium">'.$bal1,'                                        </h2>',2,$new->dash());
    echo "{$red}3 satoshi has been added for you {$blue}Balance: {$green2}$balance1 $putih\n";
    echo $new->timer(300);
}

case 2;
//OPEN surfads
echo $new->msg("Surf Ads Started").$new->jeda().$new->rm();
while(true){
$go1=$new->surfad();
$id=$new->pars('surfm.php?adc=','">',1,$go1);
$rw = "
												";
$reward=$new->pars('text-danger font-weight-medium">'.$rw,'</h3>',1,$go1);
if($id<=null){
  echo "Surfads Habis";
  exit;
}else{}
  //Claim ads
  $claim=$new->verify1($id);
  $balance2=$new->pars('<h2 class="text-dark mb-1 font-weight-medium">'.$bal1,'                                        </h2>',2,$new->dash());
  echo "{$yellow}Success Visit Ads {$red}$reward Satoshi {$blue}Balance: {$green2}$balance2 $putih\n";

}

case 3;
//OPEN Windowads
echo $new->msg("Window Ads Started").$new->jeda().$new->rm();
while(true){
  $go2=$new->windowads();
  $id1=$new->pars('winm.php?adc=','">',1,$go2);
  $rw = "
												";
  $rwrd=$new->pars('text-danger font-weight-medium">'.$rw,'</h3>',1,$go2);
  if($id1<=null){
    echo "Windowads Habis";
    exit;
  }else{}
    //Claim ads
    $claim=$new->verify2($id1);
    $balance3=$new->pars('<h2 class="text-dark mb-1 font-weight-medium">'.$bal1,'                                        </h2>',2,$new->dash());
    echo "{$yellow}Success Visit Ads {$red}$rwrd Satoshi {$blue}Balance: {$green2}$balance3 $putih\n";
}

case 4;
//OPEN flashads
echo $new->msg("Flashads Started").$new->jeda().$new->rm();
while(true){
  $go3=$new->flashads();
  $id2=$new->pars('<a href="flashm.php?adc=','">',1,$go3);
  $rw = "
												";
  $rwrd1=$new->pars('font-weight-medium">'.$rw,'</h3>',1,$go3);
  if($id2<=null){
    echo "Flashads Habis";
    exit;
  }else{}
    //Claim ads
    $claim=$new->verify3($id2);
    $balance3=$new->pars('<h2 class="text-dark mb-1 font-weight-medium">'.$bal1,'                                        </h2>',2,$new->dash());
    echo "{$yellow}Success Visit Ads {$red}$rwrd1 Satoshi {$blue}Balance: {$green2}$balance3 $putih\n";
}
}
