<?php

$header=array(
"user-agent: Dart/2.10 (dart:io)",
"authorization: Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiI4IiwianRpIjoiNWFmYjM5ZjhhY2ZhYzg5YmRkNTlhYWExYmQyNDI3ZWQzY2NhYjI5MDQzYTNiMjI2OTE5MjBiMGNlZjZjMWI2YzRmMzQ1N2E0MDljOTk0ODEiLCJpYXQiOjE2MzE2NjMwOTIsIm5iZiI6MTYzMTY2MzA5MiwiZXhwIjoxNjYzMTk5MDkxLCJzdWIiOiI0ODMwMSIsInNjb3BlcyI6W119.xeYkPa28qQNepp7VdxFEUyqMsylHcv_ZesdzYdUh3-T6HUCKxpYaoEvbVGsYfl4dcvD9N71RjzfakKyamFAZVIptOBusO4z7G_7qnUUsEej7-RIf1j6PLMOg8LHMeQYWWJLrnQUwZmYY7IaZXMH-Isppaajk6tK4fbnddo2pto4sjIWX_w1wpWlvkuda8Ic7zQiYJ19in8jhzwnfEHLz2Lv02C5s_K713bvpk4dDRKGY3750SWbYdGDYWXTM6Ih36Y8dtE3tieuhI21eB3wZLsWFSsW-Q6UPllusxBwuemEGBXMrJQIyS1Q2kU3cwd_GywZWvXHt83tGWh5Ez-XgII4cQsqFg5lJByPnMAWwBRzwKiMe-2iPbqsKbKR1eNiGYSxw0VzBD4DnvZ8EGUD8yP7E3oWx2TUGdUnEtklJThkQV4PZtZk5uovtWnx0Pcw33qlGX0a8_nm1IF_k5JH7I6oFUmqTmA-DvuwG7h8iXA3LOW5_OMHXopO1aE96ByO3TJ4EcaMffTfWBTZEano0vzXidTvwkEfe3wXSiGIWi2TwR6Cl8HTOdnZ574nxrrinCo5WHkSeFxGPE_OMV4SAm7ogteX_ezEjIh_X9-CkWm4BEqHf5GSHKkzfGosDF6SQ8z48dirSPIAIWOWHsNh44stZFi0sQCFLXsvoIJoa3z4",
"host: 93.115.79.8:8091"
);

$ch = curl_init();
  curl_setopt($ch,CURLOPT_URL, "http://93.115.79.8:8091/api/user/credit/set/ads");
  curl_setopt($ch,CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_HTTPHEADER, $header);
  curl_setopt($ch,CURLOPT_POST, 1);
  curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch,CURLOPT_POSTFIELDS, "");
  $res=curl_exec($ch);

echo "\n".$res;

$ch = curl_init();
  curl_setopt($ch,CURLOPT_URL, "http://93.115.79.8:8091/api/user/credit/get/all");
  curl_setopt($ch,CURLOPT_FOLLOWLOCATION, 1);
  curl_setopt($ch,CURLOPT_RETURNTRANSFER, 1);
  curl_setopt($ch,CURLOPT_HTTPHEADER, $header);
  curl_setopt($ch,CURLOPT_POST, 1);
  curl_setopt($ch,CURLOPT_SSL_VERIFYPEER, 0);
  curl_setopt($ch,CURLOPT_POSTFIELDS, "");
  $res=curl_exec($ch);

echo "\n".$res;
