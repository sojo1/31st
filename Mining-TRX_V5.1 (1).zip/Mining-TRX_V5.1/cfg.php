<?php

$session_token="e4dd5c433bc978ef5fc0bcec4a5ebb1532b34e828d44f8f5be0310788d184554";
$faucetpay="h2p14lh31ic242s28s0ev5a5rk";
$remember_me="559393%3Ad8533f2cefcf6a9ef8447e0cff96a7a99d4d7ec6f57494f0cd034721fdb5e5c4%3A4ba7e425349ad249f24133eac9ede56efcd3d151ecde5dd8289eb53e02077a97";

$w1="your wallet";
$w2="your wallet";
$w3="your wallet";
$w4="your wallet";
$w5="your wallet";
$w6="your wallet";
$w7="stop";